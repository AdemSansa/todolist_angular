
export const environement = {
    production: false,
    apiUrl: 'http://localhost:8500/api'
}