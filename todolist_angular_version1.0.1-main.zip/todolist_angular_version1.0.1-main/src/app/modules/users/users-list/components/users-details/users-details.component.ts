import { Component } from '@angular/core';

@Component({
  selector: 'app-users-details',
  imports: [],
  templateUrl: './users-details.component.html',
  styleUrl: './users-details.component.css'
})
export class UsersDetailsComponent {

}
